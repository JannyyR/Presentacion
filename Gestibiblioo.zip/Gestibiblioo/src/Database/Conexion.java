/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.Connection;
//Imporatmos la libreria Connection 
import java.sql.DriverManager;
//Imporatmos la libreria DriverManager
import java.sql.SQLException;
//Imporatmos la libreria SQLException
import javax.swing.JOptionPane;
//Imporatmos la libreria JOptionPane

public class Conexion {
    //Declaramos la clase Conexion que pertenece al paquete Database
    private final String DRIVER="com.mysql.jdbc.Driver";
    //Se especifica el driver de MySQL que se usará para la conexión
    private final String URL="jdbc:mysql://localhost:3306/";
    //Se define la URL base de la conexión
    private final String DB="dbsistemaventas";
    //Se especifica el nombre de la base de datos a la que se conectará
    private final String USER="root";
    // root es el usuario predeterminado en MySQL
    private final String PASSWORD="";
    // "" significa que la contraseña está vacía
    
    public Connection cadena;
    //Se declara una variable de tipo Connection para guardar la conexion a la base de datos
    public static Conexion instancia;
    //Se declara una variable estática instancia que almacenará una única instancia de la clase Conexion
    
    private Conexion(){
        //Se evita que se creen instancias de Conexion desde fuera de la clase
        this.cadena=null;
        //Se inicializa cadena en null
    }
    
    public Connection conectar(){
        try {
            Class.forName(DRIVER);
            //Cargar el driver de MySQL en memoria
            this.cadena=DriverManager.getConnection(URL+DB,USER,PASSWORD);
            //Establece la conexión con la base de datos usando DriverManager.getConnection() y guardala cadena
        } catch (ClassNotFoundException | SQLException e) {
            //Captura dos tipos de excepciones
            JOptionPane.showMessageDialog(null, e.getMessage());
            System.exit(0);
            //Muestra un error y cierra el programa en caso de fallo
        }
        return this.cadena;
        //Retorna el objeto Connection para que otras clases puedan usar la conexión
    }
    
    public void desconectar(){
        //Método para cerrar la conexión con la base de datos
        try {
            this.cadena.close();
        } catch (SQLException e) {
            //cerrar la conexión
            JOptionPane.showMessageDialog(null, e.getMessage());
            //Muestra un mensaje de error si la desconexión falla
        }
    }
    
    public synchronized static Conexion getInstancia(){
        //Método getInstancia() que implementa el patrón Singleton
        if (instancia==null){
            instancia=new Conexion();
            //Si instancia es null, crea una nueva instancia de Conexion
        }
        return instancia;
    }
}